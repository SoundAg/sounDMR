# sounDMR 2.1.0

* Package updated to handle large bed files incase of whole genome sequencing
	-Incldues fix for memory leaks
	-A built-in method to split large bed files by chromosome

# sounDMR 2.0.0

* Initial public release!
